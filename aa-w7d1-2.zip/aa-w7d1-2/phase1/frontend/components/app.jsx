import React from 'react';
import ToDoListContainer from './todos/todo_list_container.jsx';

const App = ()=>  {
  return ( <ToDoListContainer/> );
};

export default App;
